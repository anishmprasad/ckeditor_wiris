/* jshint esversion:5 */

var FormulaRenderer = (function() {
	'use strict';

	var mathjaxQueuedNodes = [];

	var registeredRenderers = {
		'mathml': renderMathML,
		'latex': renderLaTeX,
		'png': renderServices.bind(null, 'png'),
		'svg': renderServices.bind(null, 'svg'),
		'pdf': renderPDF,
		'eps': function() { throw "Not implemented"; },
		'swf': renderServices.bind(null, 'swf'),
		'handwritten': renderHandwritten,
		'browser': renderBrowser,
		'viewer': renderViewer,
		'mathjax': renderMathjax
	};

	var defaultBasePath = '../editorservice.aspx'; /* Replaced at build time */
	var wirisViewer = null;
	var renderParamsFilter = function(p) { return p !== 'centerbaseline' && p !== '__server'; };

	// Initialize viewer
	if (com && com.wiris && com.wiris.js && com.wiris.js.JsViewerMain) {
		wirisViewer = com.wiris.js.JsViewerMain.newInstance();
		wirisViewer.insertCSS();
	}

	// Escapes non-ASCII characters to ampersand entities
	function encodeMathML(mml) {
		return mml.replace(/[^\x00-\x7f]/g, function(m) { return '&#' + m.charCodeAt(0) + ';'; });
	}

	function getRenderServiceURL(mml, opts) {
		var basePath = opts.__server || defaultBasePath;
		var queryString = '?centerbaseline=false&mml=' + encodeURIComponent(encodeMathML(mml));

		Object.keys(opts).filter(renderParamsFilter).forEach(function(param) {
			queryString += '&' + encodeURIComponent(param) + '=' + encodeURIComponent(opts[param]);
		});

		return basePath + '/render' + queryString;
	}

	function renderMathML(mml) {
		var pre = document.createElement('pre');
		var code = pre.appendChild(document.createElement('code'));

		pre.classList.add('language-xml','pre_wiris');
		pre.classList.add('pre_wiris');
		code.classList.add('code_wiris');
		code.textContent = mml;

		return pre;
	}

	function renderLaTeX(mml, opts) {
		var pre = document.createElement('pre');
		pre.classList.add('language-latex','pre_wiris');
		pre.classList.add('pre_wiris');

		// Set content with the mathml2latex service
		var basePath = opts.__server || defaultBasePath;
		var xhr = new XMLHttpRequest();
		xhr.open('POST', basePath + '/mathml2latex');
		xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
		xhr.onreadystatechange = function() {
			if (xhr.readyState === 4) {
				var text = (xhr.status === 200) ? xhr.responseText : '[error]';
				var code = pre.appendChild(document.createElement('code'));
				code.textContent = text;
				code.classList.add('code_wiris');

				Prism.highlightElement(pre);
			}
		};
		xhr.send('lang=en&mml=' + encodeURIComponent(mml));

		return pre;
	}

	function renderServices(format, mml, opts) {
		var img = document.createElement('img');
		img.src = getRenderServiceURL(mml, opts);
		return img;
	}

	function pdfRenderCallback(node, pdf) {
		pdf.getPage(1).then(function(page) {
			var scale = 1.0;
			var viewport = page.getViewport(scale);

			var canvas = document.createElement('canvas');
			var context = canvas.getContext('2d');
			canvas.width = viewport.width;
			canvas.height = viewport.height;

			page.render({
				canvasContext: context,
				viewport: viewport
			});

			node.appendChild(canvas);
		});
	}

	function renderPDF(mml, opts) {
		var url = getRenderServiceURL(mml, opts);
		var wrapper = document.createElement('div');
		PDFJS.getDocument(url).then(pdfRenderCallback.bind(this, wrapper));
		return wrapper;
	}

	function renderHandwritten(mml, opts) {
		// To use the handwritten font we only need to set the wrs_handwritten class on the <math> element
		mml = mml.replace('<math', '<math class="wrs_handwritten"');

		return renderServices('png', mml, opts);
	}

	function renderBrowser(mml, opts) {
		var wrapper = document.createElement('span');
		wrapper.classList.add('mathml-browser');
		wrapper.innerHTML = mml;
		applyStyles(wrapper, opts, [ 'fontSize', 'fontFamily', 'color', 'backgroundColor' ]);

		return wrapper;
	}

	function renderViewer(mml, opts, target) {
		if (!target) {
			throw 'rendering for viewer requires target node';
		}

		if (wirisViewer !== null) {
			var wrapper = target.appendChild(document.createElement('div'));
			var viewerElement = wrapper.appendChild(document.createElement('div'));
			// TODO: disabled because they're not supported currently
			//applyStyles(viewerElement, opts, [ 'fontSize', 'fontFamily', 'color', 'backgroundColor' ]);

			try {
				wirisViewer.paintFormulaOnContainer(mml, viewerElement);
			} catch (e) {
				console.log("Exception " + e + " on mml " + mml + " with options " + opts);
			}

			return wrapper;
		} else {
			var span = document.createElement('span');
			span.innerText = 'Viewer not found!';
			return span;
		}
	}

	function renderMathjax(mml, opts) {
		var wrapper = document.createElement('span');
		wrapper.classList.add('mathjax-preview');
		wrapper.innerHTML = mml;
		applyStyles(wrapper, opts, [ 'fontSize', 'color', 'backgroundColor' ]);

		// Use flush() to finish rendering them
		mathjaxQueuedNodes.push(wrapper);

		return wrapper;
	}

	function applyStyles(target, styles, allowedStyles) {
		allowedStyles.forEach(function(styleName) {
			if (styles[styleName]) {
				target.style[styleName] = styles[styleName];
			}
		});
	}

	return {
		/**
		 * @return Node representing the rendered formula with the given parameters.
		 */
		 render: function(mml, opts, target) {
		 	if (!opts.format) {
		 		throw 'render: no format specified';
		 	} else if (!(opts.format in registeredRenderers)) {
		 		throw 'render: format ' + opts.format + ' doesn\'t exist';
		 	}

		 	var renderFunction = registeredRenderers[opts.format];
		 	var node = renderFunction(mml, opts, target);

			// Viewer renderer already takes care of inserting the node before to avoid style issues
			if (target && opts.format !== 'viewer') {
				target.appendChild(node);
			}

			if (opts.format === 'mathml') {
				Prism.highlightElement(node);
			}

			return node;
		},

		// Renders queueable nodes as a unit for (way) better performance
		// Note that MathJax formulas need this to be rendered!
		flush: function() {
			if (mathjaxQueuedNodes.length > 0) {
				var nodes = mathjaxQueuedNodes;
				mathjaxQueuedNodes = [];

				MathJax.Hub.Queue([ 'Typeset', MathJax.Hub, nodes, function() {
					nodes.forEach(function(e) { e.classList.remove('mathjax-preview'); });
				} ]);
			}
		}
	};
})();
