/* jshint esversion:5 */

var UIBuilder = (function() {
	function buildCustomFormulaContainer(label) {
		var container = document.createElement('div');
		container.classList.add('formula-container', 'formula-container-code');

		var labelContainer = container.appendChild(document.createElement('div'));
		var formulaContainer = container.appendChild(document.createElement('div'));
		labelContainer.appendChild(document.createTextNode(label));

		return container;
	}

	return {
		buildOption: function(param, label, choices, defaultValue, callback) {
			var optionsFragment = document.createDocumentFragment();
			choices.forEach(function(c) {
				var $option = document.createElement('option');
				$option.value = c.value;
				$option.appendChild(document.createTextNode(c.label || c.value));

				if (defaultValue && defaultValue === c.value) {
					$option.selected = true;
				}

				optionsFragment.appendChild($option);
			});

			var $label = document.createElement('span');
			$label.appendChild(document.createTextNode(label));

			var $select = document.createElement('select');
			$select.addEventListener('change', function() { callback(param, $select.value); });
			$select.appendChild(optionsFragment);

			var fragment = document.createDocumentFragment();
			fragment.appendChild($label);
			fragment.appendChild($select);
			return fragment;
		},

		buildGroupOption: function(param, label, choices, defaultValues, callback) {
			var listFragment = document.createDocumentFragment();

			choices.forEach(function(c, index) {
				var $li = document.createElement('li');
				var $label = document.createElement('label');
				var $input = document.createElement('input');

				$input.type = 'checkbox';
				$input.name = 'gallery-group-option';
				$input.value = c.value;
				$input.checked = defaultValues.indexOf(c.value) >= 0;
				$input.addEventListener('change', function() { callback(param, c.value, $input.checked); });

				$label.appendChild($input);
				$label.appendChild(document.createTextNode(c.label));
				$li.appendChild($label);
				listFragment.appendChild($li);
			});

			var $span = document.createElement('span');
			$span.appendChild(document.createTextNode(label));

			var $ul = document.createElement('ul');
			$ul.appendChild(listFragment);

			var fragment = document.createDocumentFragment();
			fragment.appendChild($span);
			fragment.appendChild($ul);
			return fragment;
		},

		buildCategoryNavigator: function(categories, callback) {
			var makeItem = function(category, index) {
				var li = document.createElement('li');
				var span = li.appendChild(document.createElement('span'));
				span.appendChild(document.createTextNode(category.name));
				li.addEventListener('click', callback.bind(null, index, li));
				return li;
			};

			var fragment = document.createDocumentFragment();
			fragment.appendChild(makeItem({ id: '__all', name: 'All' }, -1));
			fragment.appendChild(makeItem({ id: '__custom', name: 'Custom' }, -2));
			categories.map(makeItem).forEach(function(n) { fragment.appendChild(n); });

			var ul = document.createElement('ul');
			ul.appendChild(fragment);
			return ul;
		},

		buildCustomFormulaContainers: function(opt) {
			var fragment = document.createDocumentFragment();

			opt.values.forEach(function(v) {
				var n = buildCustomFormulaContainer(v.label);
				Utils.hideNode(n);
				fragment.appendChild(n);
			});

			return fragment;
		},

		buildTable: function(headers) {
			return new FormulaTable(headers);
		}
	};
})();
