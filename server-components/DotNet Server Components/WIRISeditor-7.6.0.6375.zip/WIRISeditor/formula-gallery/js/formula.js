/* jshint esversion:5 */

function Formula(mml, category) {
	this.mathML = mml;
	this.category = category;
	this.groupNodes = {};
}

Formula.prototype.setNode = function(group, node) {
	this.groupNodes[group] = node;
};

Formula.prototype.hasNode = function(group) {
	return this.groupNodes.hasOwnProperty(group) && this.groupNodes[group] !== null;
};

Formula.prototype.invalidate = function() {
	Object.keys(this.groupNodes).forEach(Formula.prototype.invalidateGroup, this);
};

Formula.prototype.invalidateGroup = function(group) {
	Utils.removeNode(this.groupNodes[group]);
	this.groupNodes[group] = null;
};
