/* jshint esversion:5 */

function FormulaTable(headers) {
	this.tableNode = document.createElement('table');
	this.groupRow = this.tableNode.appendChild(document.createElement('thead')).appendChild(document.createElement('tr'));
	this.tableBody = this.tableNode.appendChild(document.createElement('tbody'));
	this.numRows = 0;
	this.numColumns = headers.length;

	headers.forEach(function(h) {
		var td = document.createElement('td');
		td.classList.add('hidden');
		td.appendChild(document.createTextNode(h));
		this.groupRow.appendChild(td);
	}, this);
}

FormulaTable.prototype.insertInto = function(node) {
	node.appendChild(this.tableNode);
};

FormulaTable.prototype.addRows = function(num) {
	for (var i = 0; i < num; ++i) {
		var tr = document.createElement('tr');
		Utils.hideNode(tr);

		for (var j = 0; j < this.numColumns; ++j) {
			var td = document.createElement('td');
			Utils.hideNode(td);
			tr.appendChild(td);
		}

		this.tableBody.appendChild(tr);
	}

	this.numRows += num;
};

FormulaTable.prototype.addColumn = function(label, tooltip) {
	var td = document.createElement('td');
	td.setAttribute('tooltip', tooltip);
	td.appendChild(document.createTextNode(label));

	this.groupRow.appendChild(td);

	Array.from(this.tableBody.childNodes).forEach(function(tr) {
		tr.appendChild(document.createElement('td'));
	}, this);
};

FormulaTable.prototype.removeColumn = function(index) {
	var removeNode = function(node) {
		node.parent.removeChild(node);
	};
	this.applyColumn(index, removeRowChild, true);
};

FormulaTable.prototype.setColumnVisibility = function(index, visible) {
	this.applyColumn(index, (visible ? Utils.showNode : Utils.hideNode), true);
};

FormulaTable.prototype.setRowVisibility = function(index, visible) {
	this.applyRow(index, visible ? Utils.showNode : Utils.hideNode);
};

FormulaTable.prototype.setContent = function(rowIndex, colIndex, node) {
	var targetNode = this.getCellNode(rowIndex, colIndex);
	while (targetNode.firstChild) {
		targetNode.removeChild(targetNode.firstChild);
	}

	targetNode.appendChild(node);
};

FormulaTable.prototype.getCellNode = function(rowIndex, colIndex) {
	return this.tableBody.childNodes[rowIndex].childNodes[colIndex];
};

FormulaTable.prototype.applyRow = function(rowIndex, fun) {
	fun(this.tableBody.childNodes[rowIndex]);
};

FormulaTable.prototype.applyColumn = function(colIndex, fun, includeHeader) {
	if (includeHeader) {
		fun(this.groupRow.childNodes[colIndex]);
	}

	Array.from(this.tableBody.childNodes).forEach(function(tr) {
		fun(tr.childNodes[colIndex]);
	}, this);
};

FormulaTable.prototype.setRowClickListener = function(listener) {
	for (var i = 0; i < this.numRows; ++i) {
		var tr = this.tableBody.childNodes[i];
		tr.addEventListener('click', listener.bind(null, i));
	}
};
