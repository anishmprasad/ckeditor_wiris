/* jshint esversion:5 */

var allowedGroupOptions = [ 'format', 'fontFamily', 'fontSize', '__server' ];

function getParams(string) {
	var regex = /([^=&]+)(=?)([^&]*)/g;
	var match, params = {};

	while ((match = regex.exec(string)) !== null) {
		params[decodeURIComponent(match[1])] = match[2] ? decodeURIComponent(match[3]) : null;
	}

	return params;
}

// Check URL for parameters
var queryParams = getParams(window.location.hash.substring(1));

// Configure gallery options
var groupOption = (allowedGroupOptions.indexOf(queryParams.groupOption) >= 0) ? queryParams.groupOption : 'format';
var galleryOptions = [
	{
		param: 'format',
		label: 'Format',
		defaultAsOption: 'png',
		defaultAsGroup: [ 'png', 'svg', 'browser' ],
		values: [
			{ value: 'mathml', label: 'MathML' },
			{ value: 'latex', label: 'LaTeX' },
			{ value: 'png', label: 'PNG' },
			{ value: 'svg', label: 'SVG' },
			{ value: 'pdf', label: 'PDF' },
			//{ value: 'eps', label: 'EPS' },
			{ value: 'handwritten', label: 'Handwritten font' },
			{ value: 'browser', label: 'Current browser' },
			{ value: 'viewer', label: 'Viewer' },
			{ value: 'mathjax', label: 'MathJax' }
		]
	},
	{
		param: 'fontFamily',
		label: 'Font',
		defaultAsOption: 'stix',
		defaultAsGroup: [ 'Arial', 'stix', 'Courier New' ],
		values: [
			{ value: 'inherit', label: '(Editor default)' },
			{ value: 'Arial', label: 'Arial' },
			{ value: 'stix', label: 'Classic' },
			{ value: 'Courier New', label: 'Courier New' },
			{ value: 'Tahoma', label: 'Tahoma' },
			{ value: 'Times New Roman', label: 'Times New Roman' },
			{ value: 'Verdana', label: 'Verdana' },
		]
	},
	{
		param: 'fontSize',
		label: 'Font size',
		defaultAsOption: '16px',
		defaultAsGroup: [ '8px', '12px', '16px', '18px' ], // Nonsensical
		values: [
			8, 9, 10, 11, 12, 14, 16, 18, 20, 22, 24, 26, 28, 36, 48, 72
		].map(function(s) {
			return { value: s + 'px', label: s + 'px' };
		})
	},
	{
		param: 'color', // TODO selector
		label: 'Font color',
		defaultAsOption: 'black',
		defaultAsGroup: null,
		values: [ 'black', 'red', 'green', 'blue', 'yellow', 'white' ].map(function(s) {
			return { value: s, label: s };
		})
	},
	{
		param: 'backgroundColor', // TODO selector
		label: 'Background color',
		defaultAsOption: 'transparent',
		defaultAsGroup: null,
		values: [ 'transparent', 'black', 'red', 'green', 'blue', 'yellow', 'white' ].map(function(s) {
			return { value: s, label: s };
		})
	}
];

var initializeGallery = function(jsonFormulaData) {
	Gallery.loadFormulas(jsonFormulaData);

	galleryOptions.forEach(function(o) {
		Gallery.addOption(o, o.param === groupOption, queryParams[o.param]);
	});

	Gallery.setDOMElements({
		groups: document.getElementById('gallery-groups'),
		options: document.getElementById('gallery-options'),
		categories: document.getElementById('gallery-categories'),
		table: document.getElementById('gallery-table'),
		customSection: document.getElementById('gallery-custom'),
		customEditor: document.getElementById('gallery-custom-editor'),
		customFormulas: document.getElementById('gallery-custom-wrapper')
	});

	Gallery.setDefaultFormulaCategory(queryParams.category);

	Gallery.run();
	//Gallery.addCustomGroup({ format: 'png', fontSize: '42px', fontFamily: 'Courier New' });
};

// Load data
var xhr = new XMLHttpRequest();
xhr.responseType = 'text';
xhr.open('GET', 'formulas.json');
xhr.onreadystatechange = function() {
	if (xhr.readyState !== XMLHttpRequest.DONE) {
		return;
	}

	if (xhr.status === 200) {
		var json = JSON.parse(xhr.responseText);
		initializeGallery(json);
	} else {
		var $box = document.getElementById('error-box');
		if (xhr.status === 404) {
			$box.textContent = "Formula data couldn't be retrieved from the server!";
		} else {
			$box.textContent = "Unknown error while loading formula data: " + xhr.status + "";
		}
		$box.classList.remove('hidden');
	}
};

xhr.send(null);
