/* jshint esversion:5 */

function Category(id, name) {
	this.id = id;
	this.name = name;
	this.formulas = [];
	this.formulaIndices = [];

	/** Custom formula node */
	this.customNode = null;
}

Category.prototype.addFormula = function(formula, index) {
	this.formulas.push(formula);
	this.formulaIndices.push(index);
};

Category.prototype.invalidate = function() {
	this.formulas.forEach(function(f) {
		f.invalidate();
	});

	if (this.customNode) {
		Utils.removeNode(this.customNode);
		this.customNode = null;
	}
};
