/* jshint esversion:5 */

var Gallery = (function() {
	'use strict';

	var CATEGORY_ALL = -1;
	var CATEGORY_CUSTOM = -2;

	// Data
	var formulas = null; // Formula objects
	var categories = null; // Category objects

	var options = [];
	var groupOption = null;

	var domElements = null;
	var tableInstance = null;

	var customEditorInstance = null;

	// State
	var currentCategory = -1;
	var currentCategoryNode = null;
	var currentCustomGroups = []; // { id, opts }
	var currentOptions = {};
	var currentGroupVisibility = null;

	var running = false;

	// Helper functions
	var getCategoryById = function(id) {
		return categories.find(function(c) {
			return c.id === id;
		});
	};

	var showRow = function(idx) { tableInstance.setRowVisibility(idx, true); };
	var hideRow = function(idx) { tableInstance.setRowVisibility(idx, false); };

	var showCategory = function(idx) { categories[idx].formulaIndices.forEach(showRow); };
	var hideCategory = function(idx) { categories[idx].formulaIndices.forEach(hideRow); };

	// Custom formula rendering
	var CUSTOM_RENDER_DELAY = 1000;
	var customRenderTimeoutId = -1;

	function renderCustomFormulas() {
		var mml = customEditorInstance.getMathML();
		var groupIndices = currentGroupVisibility.map(function(v, idx) {
			return v ? idx : -1;
		}).filter(function(i) {
			return i >= 0;
		});

		// TODO: render custom columns too

		groupIndices.forEach(function(groupIndex) {
			var target = domElements.customFormulas.childNodes[groupIndex].childNodes[1]; // TODO ew
			var node = renderMathML(mml, groupOption.values[groupIndex].value, target);
			Utils.removeChildren(target);
			target.appendChild(node);
		});

		FormulaRenderer.flush();
	}

	function signalFormulaChanged(delay) {
		if (customRenderTimeoutId !== -1) {
			clearTimeout(customRenderTimeoutId);
		}

		// TODO: replace container contents with a 'loading' animation?
		customRenderTimeoutId = setTimeout(renderCustomFormulas, (delay !== undefined) ? delay : CUSTOM_RENDER_DELAY);
	}

	//
	var categoryIndexToId = function(idx) {
		if (idx === CATEGORY_ALL) {
			return  '__all';
		} else if (idx === CATEGORY_CUSTOM) {
			return '__custom';
		} else {
			return categories[idx].id;
		}
	};

	function updateURLHash() {
		var newHash = '#';

		// Group option
		if (groupOption.param !== 'format') {
			newHash += 'groupOption=' + groupOption.param + '&';
		}

		// Formula category
		newHash += 'category=' + categoryIndexToId(currentCategory);

		// Group option values
		var isOptionVisible = function(_, i) { return currentGroupVisibility[i]; };
		var getOptionValue = function(o) { return o.value; };

		var joinedGroups = groupOption.values.filter(isOptionVisible).map(getOptionValue).join(',');
		newHash += '&' + groupOption.param + '=' + encodeURIComponent(joinedGroups);

		// Regular option values
		var paramFilter = function(p) { return p !== groupOption.param; };
		var paramToComponent = function(p) { return '&' + encodeURIComponent(p) + '=' + encodeURIComponent(currentOptions[p]); };

		newHash += Object.keys(currentOptions).filter(paramFilter).map(paramToComponent).join('');
		window.location.hash = newHash;
	}

	// Remember to call FormulaRenderer.flush() after calling this!
	function renderMathML(mml, group, target) {
		var customGroup = currentCustomGroups.find(function(cg) { return cg.id === group; });
		var opts;

		if (customGroup !== undefined) {
			opts = customGroup.options;
		} else {
			currentOptions[groupOption.param] = group;
			opts = currentOptions;
		}

		return FormulaRenderer.render(mml, opts, target);
	}

	// Remember to call FormulaRenderer.flush() after calling this!
	function renderFormula(formula, group, target) {
		var node = renderMathML(formula.mathML, group, target);
		formula.setNode(group, node);
	}

	function checkFormulasForRendering(groups) {
		if (!running || currentCategory === -2) {
			return;
		}

		var formulaIndices;
		if (currentCategory !== CATEGORY_ALL) {
			formulaIndices = categories[currentCategory].formulaIndices;
		} else {
			formulaIndices = formulas.map(function(_, idx) { return idx; });
		}

		var groupValues = groups || currentGroupVisibility.map(function(v, idx) {
			return v ? idx : -1;
		}).filter(function(i) {
			return i >= 0;
		}).map(function(i) {
			return groupOption.values[i].value;
		});

		if (!groups) {
			groupValues = groupValues.concat(currentCustomGroups.map(function(cg) { return cg.id; }));
		}

		groupValues.forEach(function(group) {
			var customGroup = currentCustomGroups.find(function(cg) { return cg.id === group; });
			var queuedIndices = formulaIndices.filter(function(idx) { return !formulas[idx].hasNode(group); });
			var groupIndex;

			if (customGroup !== undefined) {
				groupIndex = groupOption.values.length + currentCustomGroups.indexOf(customGroup);
			} else {
				groupIndex = groupOption.values.findIndex(function(opt) { return opt.value === group; });
			}

			queuedIndices.forEach(function(idx) {
				renderFormula(formulas[idx], group, tableInstance.getCellNode(idx, groupIndex));
			});
		});

		FormulaRenderer.flush();
	}

	// Event hooks
	function onCategoryChanged(index, node) {
		if (currentCategoryNode) {
			currentCategoryNode.classList.remove('selected');
		}

		if (node) {
			node.classList.add('selected');
		}

		if (currentCategory >= 0) {
			hideCategory(currentCategory);
		} else if (currentCategory === CATEGORY_ALL) {
			for (var i = 0; i < categories.length; ++i) {
				hideCategory(i);
			}
		} else if (currentCategory === CATEGORY_CUSTOM) {
			Utils.hideNode(domElements.customSection);
			Utils.showNode(domElements.table);
		}

		currentCategory = index;
		currentCategoryNode = node;
		updateURLHash();

		if (index >= 0) {
			showCategory(index);
		} else if (index === -1) {
			for (var j = 0; j < categories.length; ++j) {
				showCategory(j);
			}
		} else if (index === -2) {
			loadCustomEditor();
			Utils.hideNode(domElements.table);
			Utils.showNode(domElements.customSection);
		}

		checkFormulasForRendering();
	}

	function onOptionChanged(paramName, paramValue, checked) {
		if (checked === undefined) {
			checked = null;
		}

		var optionValues = options.find(function(o) { return o.param === paramName; });
		optionValues = optionValues.values;
		var valueIndex = optionValues.findIndex(function(v) { return v.value === paramValue; });

		var groupsToRender = null;

		if (paramName !== groupOption.param) {
			currentOptions[paramName] = paramValue;

			formulas.forEach(function(f) { f.invalidate(); });
			checkFormulasForRendering();
		} else {
			if (checked === null) {
				throw 'onOptionChanged: group option with null checked value';
			}

			if (!groupOption.values.some(function(v) { return v.value === paramValue; })) {
				throw 'onOptionChanged: value \'' + paramValue + '\' doesn\'t exist';
			}

			currentGroupVisibility[valueIndex] = checked;
			tableInstance.setColumnVisibility(valueIndex, checked);
			Utils.setNodeVisibility(domElements.customFormulas.childNodes[valueIndex], checked);
			groupsToRender = [ paramValue ];
		}

		updateURLHash();

		if (currentCategory === CATEGORY_CUSTOM) {
			signalFormulaChanged(0);
		} else {
			checkFormulasForRendering(groupsToRender);
		}
	}

	function loadCustomEditor() {
		if (customEditorInstance !== null) {
			return;
		}

		customEditorInstance = com.wiris.js.JsEditor.newInstance();
		customEditorInstance.getEditorModel().addEditorListener({
			contentChanged: function() {
				signalFormulaChanged();
			},
			styleChanged: signalFormulaChanged,
			caretPositionChanged: function() {},
			clipboardChanged: function() {},
			transformationReceived: function() {}
		});
		customEditorInstance.insertInto(domElements.customEditor);
	}

	return {
		loadFormulas: function(json) {
			formulas = json.formulas.map(function(f) {
				return new Formula(f.mml, f.category);
			});

			categories = json.categories.map(function(c) {
				var category = new Category(c.id, c.name);

				formulas.forEach(function(f, index) {
					if (f.category === c.id) {
						category.addFormula(f, index);
					}
				});

				return category;
			});
		},

		// call only after .run()!
		addCustomGroup: function(options) {
			var customGroup = { id: null, options: options };
			var groupIndex = currentCustomGroups.push(customGroup) - 1;
			customGroup.id = '__custom' + groupIndex;

			// Generate tooltip from options
			var p2t = function(param) { return param + ': ' + options[param];  };
			var tooltip = '{ ' + Object.keys(options).map(p2t).join(', ') + ' }';

			tableInstance.addColumn('Custom #' + (groupIndex + 1), tooltip);
			// TODO add custom formula node container
			checkFormulasForRendering([ customGroup.id ]);
		},

		addOption: function(optionData, isGroupOption, defaultValue) {
			if (isGroupOption && groupOption) {
				throw 'group option already set: ' + groupOption.param;
			}

			options.push(optionData); // TODO?

			if (isGroupOption) {
				groupOption = optionData;

				var listDefaults = optionData.defaultAsGroup;
				if (defaultValue) {
					var splitValues = defaultValue.split(',');
					if (splitValues.every(function(s) { return optionData.values.some(function(v) { return v.value === s; }); })) {
						listDefaults = splitValues;
					} else {
						console.log('addOption: invalid default value for ' + optionData.param + ' \'' + defaultValue + '\'');
					}
				}

				currentGroupVisibility = optionData.values.map(function(v) { return listDefaults.indexOf(v.value) >= 0; });
			} else {
				if (defaultValue && !optionData.values.find(function(opt) { return opt.value === defaultValue; })) {
					console.log('addOption: invalid default value for ' + optionData.param + ': ' + defaultValue);
					currentOptions[optionData.param] = optionData.defaultAsOption;
				} else {
					currentOptions[optionData.param] = defaultValue || optionData.defaultAsOption;
				}
			}
		},

		setDOMElements: function(elems) {
			var requiredElements = [ 'groups', 'options', 'categories', 'table', 'customSection', 'customEditor', 'customFormulas' ];
			if (!domElements && requiredElements.every(function(k) { return elems[k]; })) {
				domElements = elems;
			} else {
				throw 'dom elements already set or missing element';
			}
		},

		setDefaultFormulaCategory: function(categoryId) {
			if (categoryId === '__all') {
				currentCategory = -1;
			} else if (categoryId === '__custom') {
				currentCategory = -2;
			} else {
				var categoryIndex = categories.findIndex(function(c) { return c.id == categoryId; });
				if (categoryIndex >= 0) {
					currentCategory = categoryIndex;
				} else {
					console.log('setDefaultFormulaCategory: couldn\'t find category \'' + categoryId + '\'');
					currentCategory = 0;
				}
			}
		},

		run: function() {
			if (!domElements || !formulas || !options || !groupOption) {
				throw 'not initialized';
			}

			var groupDefaultValues = groupOption.values.filter(function(_, idx) { return currentGroupVisibility[idx]; }).map(function(v) { return v.value; });

			// Gallery options
			var makeGroupOption = function(opt) { return UIBuilder.buildGroupOption(opt.param, opt.label, opt.values, groupDefaultValues, onOptionChanged); };
			domElements.groups.appendChild(makeGroupOption(groupOption));

			var makeRegularOption = function(opt) { return UIBuilder.buildOption(opt.param, opt.label, opt.values, currentOptions[opt.param], onOptionChanged); };
			var regularOptions = options.filter(function(o) { return o.param !== groupOption.param; });
			regularOptions.map(makeRegularOption).forEach(function(n) { domElements.options.appendChild(n); });

			// Custom formula containers for every group option
			domElements.customFormulas.appendChild(UIBuilder.buildCustomFormulaContainers(groupOption));

			// Formula category selector
			var categoryNavi = UIBuilder.buildCategoryNavigator(categories, onCategoryChanged);
			domElements.categories.appendChild(categoryNavi);

			// Formula table
			tableInstance = UIBuilder.buildTable(groupOption.values.map(function(v) { return v.label; }));
			tableInstance.insertInto(domElements.table);

			// Initialize state
			tableInstance.addRows(formulas.length);
			currentCategory = Math.min(Math.max(-2, currentCategory), categories.length - 1);
			currentCategoryNode = categoryNavi.childNodes[currentCategory < 0 ? (-currentCategory - 1): (currentCategory + 2)];

			// Show default columns and rows
			running = true;
			groupDefaultValues.forEach(function(v) { onOptionChanged(groupOption.param, v, true); });
			onCategoryChanged(currentCategory, currentCategoryNode);
		}
	};
})();
