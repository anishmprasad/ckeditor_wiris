/* jshint esversion:5 */

var Utils = {
	setNodeVisibility: function(n, visible) {
		if (visible) {
			n.classList.remove('hidden');
		} else {
			n.classList.add('hidden');
		}
	},

	hideNode: function(n) {
		n.classList.add('hidden');
	},

	showNode: function(n) {
		n.classList.remove('hidden');
	},

	removeNode: function(n) {
		if (n && n.parentNode) {
			n.parentNode.removeChild(n);
		}
	},

	removeChildren: function(n) {
		while (n && n.firstChild) {
			n.removeChild(n.firstChild);
		}
	}
};
