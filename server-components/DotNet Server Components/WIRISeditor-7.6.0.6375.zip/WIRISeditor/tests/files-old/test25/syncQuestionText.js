var globalIntervalFunc = null;

function startSyncQuestionText(e, func) {
	var editor = e;
	var previous = "";

	globalIntervalFunc = setInterval(function() {
		var vars = func();
		if (vars!=previous) {
			editor.setParams({'reservedWords': vars});
		}
		previous = vars;
	},500);
}

function stopSyncQuestionText(editor) {
	clearInterval(globalIntervalFunc);
	globalIntervalFunc = null;
	editor.setParams({'reservedWords': ''});
}

function yieldSync() {
	if (globalIntervalFunc==null) {
		editor.setParams({'reservedWords': ''});
	} else {
		previous = ".";
	}
}
