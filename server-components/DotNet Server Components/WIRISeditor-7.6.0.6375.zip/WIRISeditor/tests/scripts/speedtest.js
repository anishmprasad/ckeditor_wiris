var speedtest = (function() {
	'use strict';

	var NUM_LATENCY_SAMPLES = 10;
	var NUM_HANDLER_SAMPLES = 5;
	var MAX_HANDLER_ERRORS = 3;
	var DEFAULT_SAMPLING_SAMPLES = 5;
	var DEFAULT_ERROR_LIMIT = 3;
	var DEFAULT_SAMPLING_DELAY = 1000;
	var XHR_TIMEOUT = 10000;
	var XHR_REQUEST_DELAY = 1000; // Delay between two XHR requests

	function makeElement(tag, content, asHtml, parent) {
		var elem = document.createElement(tag);

		if (asHtml) {
			elem.innerHTML = content;
		} else {
			elem.innerText = content;
		}

		if (parent) {
			parent.appendChild(elem);
		}

		return elem;
	}

	function makeQueryString(params) {
		if (!params) {
			return '';
		}

		var paramKeys = Object.keys(params);
		if (paramKeys.length < 1) {
			return '';
		}

		var makePart = function(key) { return encodeURIComponent(key) + '=' + encodeURIComponent(params[key]); };
		return paramKeys.map(makePart).join('&');
	}

	function formatFloat(f, unit) {
		return ((f < 0.1) ? '&lt;0.1' : f.toFixed(1)) + '&nbsp;' + unit;
	}

	var config = {
		mmlSmall: '<math xmlns="http://www.w3.org/1998/Math/MathML"><msup><mi>a</mi><mn>2</mn></msup><mo>+</mo><msup><mi>b</mi><mn>2</mn></msup><mo>=</mo><msup><mi>c</mi><mn>2</mn></msup></math>',
		mmlLarge: '<math xmlns="http://www.w3.org/1998/Math/MathML"><msub><mi mathvariant="normal">&#x3A8;</mi><mrow class="MJX-TeXAtom-ORD"><mi>n</mi><mi>&#x2113;</mi><mi>m</mi></mrow></msub><mo>(</mo><mi>r</mi><mo>,</mo><mi>&#x3B8;</mi><mo>,</mo><mi>&#x3D5;</mi><mo>)</mo><mo>=</mo><mrow class="MJX-TeXAtom-ORD"><msqrt><msup><mrow class="MJX-TeXAtom-ORD"><mo>(</mo><mfrac><mn>2</mn><mrow><mi>n</mi><msub><mi>a</mi><mrow class="MJX-TeXAtom-ORD"><mn>0</mn></mrow></msub></mrow></mfrac><mo>)</mo></mrow><mrow class="MJX-TeXAtom-ORD"><mn>3</mn></mrow></msup><mrow class="MJX-TeXAtom-ORD"><mfrac><mrow><mo>(</mo><mi>n</mi><mo>&#x2212;</mo><mi>&#x2113;</mi><mo>&#x2212;</mo><mn>1</mn><mo>)</mo><mo>!</mo></mrow><mrow><mn>2</mn><mi>n</mi><mo>[</mo><mo>(</mo><mi>n</mi><mo>+</mo><mi>&#x2113;</mi><mo>)</mo><mo>!</mo><mo>]</mo></mrow></mfrac></mrow></msqrt></mrow><msup><mi>e</mi><mrow class="MJX-TeXAtom-ORD"><mo>&#x2212;</mo><mi>r</mi><mo>/</mo><mi>n</mi><msub><mi>a</mi><mrow class="MJX-TeXAtom-ORD"><mn>0</mn></mrow></msub></mrow></msup><msup><mrow><mo>(</mo><mrow class="MJX-TeXAtom-ORD"><mfrac><mrow><mn>2</mn><mi>r</mi></mrow><mrow><mi>n</mi><msub><mi>a</mi><mrow class="MJX-TeXAtom-ORD"><mn>0</mn></mrow></msub></mrow></mfrac></mrow><mo>)</mo></mrow><mrow class="MJX-TeXAtom-ORD"><mi>&#x2113;</mi></mrow></msup><msubsup><mi>L</mi><mrow class="MJX-TeXAtom-ORD"><mi>n</mi><mo>&#x2212;</mo><mi>&#x2113;</mi><mo>&#x2212;</mo><mn>1</mn></mrow><mrow class="MJX-TeXAtom-ORD"><mn>2</mn><mi>&#x2113;</mi><mo>+</mo><mn>1</mn></mrow></msubsup><mrow><mo>(</mo><mrow class="MJX-TeXAtom-ORD"><mfrac><mrow><mn>2</mn><mi>r</mi></mrow><mrow><mi>n</mi><msub><mi>a</mi><mrow class="MJX-TeXAtom-ORD"><mn>0</mn></mrow></msub></mrow></mfrac></mrow><mo>)</mo></mrow><mo>&#x22C5;</mo><msubsup><mi>Y</mi><mrow class="MJX-TeXAtom-ORD"><mi>&#x2113;</mi></mrow><mrow class="MJX-TeXAtom-ORD"><mi>m</mi></mrow></msubsup><mo>(</mo><mi>&#x3B8;</mi><mo>,</mo><mi>&#x3D5;</mi><mo>)</mo></math>',
		latexSmall: 'a^2+b^2=c^2',
		latexLarge: '{\\mathrm\\Psi}_{n\\ell m}(r,\\theta,\\phi)={\\sqrt{{(\\frac2{na_0})}^3{\\frac{(n-\\ell-1)!}{2n\\lbrack(n+\\ell)!\\rbrack}}}}e^{-r/na_0}{({\\frac{2r}{na_0}})}^\\ell L_{n-\\ell-1}^{2\\ell+1}{({\\frac{2r}{na_0}})}⋅Y_\\ell^m(\\theta,\\phi)',
		accessibleSmall: 'a squared plus b squared equals c squared',
		accessibleLarge: 'f subscript a open parentheses x close parentheses equals sum from n equals 0 to infinity of fraction numerator d to the power of n f over denominator d x to the power of n end fraction open parentheses a close parentheses fraction numerator x minus a over denominator n factorial end fraction equals f open parentheses a close parentheses plus fraction numerator d f over denominator d x end fraction open parentheses a close parentheses fraction numerator x minus a over denominator 1 factorial end fraction plus fraction numerator d squared f over denominator d x squared end fraction open parentheses a close parentheses fraction numerator open parentheses x minus a close parentheses squared over denominator 2 factorial end fraction plus midline horizontal ellipsis',
	};

	return {
		regionalServers: {
			'us-east-1': 'http://autoscaling.us-east-1.amazonaws.com/ping',
			'us-west-1': 'http://autoscaling.us-west-1.amazonaws.com/ping',
			'us-west-2': 'http://autoscaling.us-west-2.amazonaws.com/ping',
			'eu-west-1': 'http://autoscaling.eu-west-1.amazonaws.com/ping',
			'eu-central-1': 'http://autoscaling.eu-central-1.amazonaws.com/ping',
			'ap-southeast-1': 'http://autoscaling.ap-southeast-1.amazonaws.com/ping',
			'ap-southeast-2': 'http://autoscaling.ap-southeast-2.amazonaws.com/ping',
			'ap-northeast-1': 'http://autoscaling.ap-northeast-1.amazonaws.com/ping',
			'ap-northeast-2': 'http://autoscaling.ap-northeast-2.amazonaws.com/ping',
			'ap-south-1': 'http://autoscaling.ap-south-1.amazonaws.com/ping',
			'sa-east-1': 'http://autoscaling.sa-east-1.amazonaws.com/ping'
		},

		serviceData: {
			'viewer': {},
			'editor': {},
			'status': {},
			'license': {},

			'mathml2latex':      { method: 'POST', paramSet: { 'small': { mml: config.mmlSmall }, 'large': { mml: config.mmlLarge } } },
			'mathml2internal':   { method: 'POST', paramSet: { 'small': { mml: config.mmlSmall }, 'large': { mml: config.mmlLarge } } },
			'mathml2accessible': { method: 'POST', paramSet: { 'small': { mml: config.mmlSmall }, 'large': { mml: config.mmlLarge } } },
			'mathml2content':    { method: 'POST', paramSet: { 'small': { mml: config.mmlSmall }, 'large': { mml: config.mmlLarge } } },

			'latex2mathml':      { method: 'POST', paramSet: {
				'small': { latex: config.latexSmall },
				'large': { latex: config.latexLarge }
			}},
			'accessible2mathml': { method: 'POST', paramSet: {
				'small': { accessible: config.accessibleSmall, lang: 'en' },
				'large': { accessible: config.accessibleLarge, lang: 'en' }
			}},

			'render': { method: 'POST', paramSet: {
				'png-large': { mml: config.mmlLarge, format: 'png', dpi: 300},
				'png-small': { mml: config.mmlSmall, format: 'png', dpi: 96 },
				'svg-small': { mml: config.mmlSmall, format: 'svg' },
				'svg-large': { mml: config.mmlLarge, format: 'svg' },
				'eps-small': { mml: config.mmlSmall, format: 'eps' },
				'eps-large': { mml: config.mmlLarge, format: 'eps' },
				'pdf-small': { mml: config.mmlSmall, format: 'pdf' },
				'pdf-large': { mml: config.mmlLarge, format: 'pdf' },
				'swf-small': { mml: config.mmlSmall, format: 'swf' },
				'swf-large': { mml: config.mmlLarge, format: 'swf' }
			}}

			// TODO
			// 'content2mathml': { method: 'POST', paramSet: { TODO }  },
			// 'evaluate': { method: 'POST', paramSet: { TODO }  },
			// 'resource': { method: 'GET', paramSet: { TODO }  },
		},

		makeElement: makeElement,

		/**
		 * Returns an object containing several data metrics for a given number array.
		 */
		getStats: function(array) {
			var min = Infinity, max = -Infinity, sum = 0;
			for (var i = 0; i < array.length; ++i) {
				sum += array[i];
				min = Math.min(min, array[i]);
				max = Math.max(max, array[i]);
			}

			var avg = sum / array.length;
			var sqd_sum = 0;
			for (i = 0;  i < array.length; ++i) {
				sqd_sum += Math.pow(array[i] - avg, 2);
			}

			var sd = Math.sqrt(sqd_sum/(array.length - 1));
			return { min: min, max: max, avg: avg, sd: sd };
		},

		/**
		 * Samples the results returned by a function through a callback.
		 *
		 * If you need to pass parameters other than the callback to `callable`,
		 * use bind() but always make the callback function the first parameter!
		 *
		 * @param callable A function/BF with a callback argument used to return the values.
		 * @param callback Callback called with each sample (or nothing at all if there's an error) after finishing the sampling.
		 * @param numSamples Amount of samples to collect.
		 * @param maxErrors Maximum amount of errors to ignore before aborting.
		 * @param delay Delay between calls.
		 */
		sample: function(callable, callback, numSamples, maxErrors, delay) {
			numSamples = numSamples || DEFAULT_SAMPLING_SAMPLES;
			maxErrors = maxErrors || DEFAULT_ERROR_LIMIT;
			delay = delay || DEFAULT_SAMPLING_DELAY;

			var samples = [];
			var numErrors = 0;
			var getSample = callable.bind(null, function(x) {
				if (x !== undefined) {
					samples.push(x);
				} else {
					++numErrors;
				}

				// Return collected samples through callback or continue sampling
				if (samples.length >= numSamples) {
					return callback(samples);
				} else if (numErrors >= maxErrors) {
					return callback();
				} else {
					callback(samples);
					setTimeout(getSample, delay);
				}
			});

			// Start collecting samples
			callback(samples); // length = 0 as 'start' event
			getSample();
		},

		/**
		 * Returns a simple handler that measures the response time of a XHR.
		 * @param method GET or POST, case-insensitive.
		 */
		makeXHRFactory: function(url, params, method) {
			method = method ? method.toUpperCase() : 'GET';
			var queryString = makeQueryString(params);
			if (queryString.length > 0) {
				url += '?' + queryString;
			}

			return function(callback) {
				var startingTime;

				var xhr = new XMLHttpRequest();
				xhr.onreadystatechange = function(evt) {
					if (xhr.readyState == XMLHttpRequest.DONE && xhr.status == 200) {
						callback(new Date().getTime() - startingTime);
					} else if (xhr.readyState == XMLHttpRequest.DONE) {
						console.log("XHR to " + url + " failed with status " + xhr.statusText);
						callback();
					}
				};

				// Send XHR to url
				xhr.open(method, url);
				if (method == 'POST') {
					xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
				}
				xhr.timeout = XHR_TIMEOUT; // timeout goes here because IE<=11 complains if it's placed before open() regardless of the spec
				xhr.ontimeout = function() { callback(); };

				startingTime = new Date().getTime();
				xhr.send(method == 'POST' ? queryString : undefined);
			};
		},

		testServices: function(serviceData, tableElem, latencyData, mappingFunc, numSamples, sectionName, resultData, nextFunc) {
			var tableBody = tableElem.getElementsByTagName('tbody').item(0);

			// Transform every test case into a new table row and an XHR factory to test it
			var f = mappingFunc.bind(null, serviceData, tableBody);
			var serviceTests = Object.keys(serviceData).map(f).reduce(function(cur, next) {
				return cur.concat(next);
			}, []);

			// Chain every service sequentially
			var makeTestCallback = function(name, row, nextFunc) {
				return function(results) {
					if (results && results.length < numSamples) {
						row.lastChild.innerText = 'Analyzing... ' + results.length + '/' + numSamples;
						return;
					}

					// Completed: either success or error
					if (results) {
						var stats = speedtest.getStats(results);
						var fragment = document.createDocumentFragment();

						if (latencyData) {
							makeElement('td', formatFloat(stats.min - latencyData.min, 'ms'), true, fragment);
							makeElement('td', formatFloat(stats.avg - latencyData.avg, 'ms'), true, fragment);
							makeElement('td', formatFloat(stats.max - latencyData.min, 'ms'), true, fragment);
						}
						makeElement('td', formatFloat(stats.min, 'ms'), true, fragment);
						makeElement('td', formatFloat(stats.avg, 'ms'), true, fragment);
						makeElement('td', formatFloat(stats.max, 'ms'), true, fragment);

						row.removeChild(row.lastChild);
						row.appendChild(fragment);
					} else {
						row.lastChild.className += ' error centered';
						row.lastChild.innerText = 'Too many errors, skipping...';
					}

					resultData.add(sectionName, name, results || null);
					return nextFunc ? nextFunc() : undefined;
				};
			};

			for (var i = serviceTests.length - 1; i >= 0; --i) {
				/*serviceTests[i].nextFunc = nextFunc;*/
				var callback = makeTestCallback(serviceTests[i].name, serviceTests[i].row, nextFunc);
				nextFunc = speedtest.sample.bind(null, serviceTests[i].xhr, callback, numSamples);
			}

			return nextFunc ? nextFunc() : undefined;
		},
	};
})();
