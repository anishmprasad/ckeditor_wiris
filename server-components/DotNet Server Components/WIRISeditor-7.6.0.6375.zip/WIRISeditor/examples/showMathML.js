function showMathML(x) {
	wnd = window.open("","_blank","width=500,height=400");
	var s;
	s="<html>";
	s+="<head><link type='text/css' rel='stylesheet' media='all' href='../../style.css' /></head>";
	s+="<body><div class='main-examples'>";
	s+=x;
	x+="</div></body></html>";
	wnd.document.write(x);
}